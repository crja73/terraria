import pygame
import os
import random

WHITE = (255, 255, 255)

pygame.init()
size = width, height = 500, 500
screen = pygame.display.set_mode(size)
screen.fill(WHITE)

def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert_alpha()
    if colorkey is not None:
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Bomb(pygame.sprite.Sprite):
    image = load_image("bomb.png")
    image_boom = load_image("boom.png")

    def __init__(self, group):
        # РќР•РћР‘РҐРћР”РРњРћ РІС‹Р·РІР°С‚СЊ РєРѕРЅСЃС‚СЂСѓРєС‚РѕСЂ СЂРѕРґРёС‚РµР»СЊСЃРєРѕРіРѕ РєР»Р°СЃСЃР° Sprite. Р­С‚Рѕ РѕС‡РµРЅСЊ РІР°Р¶РЅРѕ!!!
        super().__init__(group)
        self.image = Bomb.image
        self.rect = self.image.get_rect()
 
    def update(self, event):
        self.rect.x = event[0]
        self.rect.y = event[1]


all_sprites = pygame.sprite.Group()


Bomb(all_sprites)


x = 230   #coords of main character
y = 450
count_jump = 15

jump_flag = False   # flag of jump process

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False


        

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                jump_flag = True
                count_jump = 15

        if jump_flag == True:
            if count_jump >= -15:
                y -= count_jump / 2
                count_jump -= 1
            else:
                if y < 450:
                    y = min(450, (y - count_jump / 2))
                    count_jump -= 1
                else:
                    count_jump = 15
                    jump_flag = False
        all_sprites.update([x, y])
        screen.fill(WHITE)


        all_sprites.draw(screen)
        pygame.display.flip()
        pygame.time.wait(8)
pygame.quit()