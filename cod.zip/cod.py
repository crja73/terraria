import pygame
import os
import random

WHITE = (255, 255, 255)

pygame.init()
size = width, height = 1000, 600
screen = pygame.display.set_mode(size)
screen.fill(WHITE)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert_alpha()
    if colorkey is not None:
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image

class Health_class(pygame.sprite.Sprite):
    health_level = load_image('health.png')

    def __init__(self, group):
        # РќР•РћР‘РҐРћР”РРњРћ РІС‹Р·РІР°С‚СЊ РєРѕРЅСЃС‚СЂСѓРєС‚РѕСЂ СЂРѕРґРёС‚РµР»СЊСЃРєРѕРіРѕ РєР»Р°СЃСЃР° Sprite. Р­С‚Рѕ РѕС‡РµРЅСЊ РІР°Р¶РЅРѕ!!!
        super().__init__(group)
        self.image = Health_class.health_level
        self.rect = self.image.get_rect()
 
    def update(self, event):
        self.rect.x = event[0]
        self.rect.y = event[1]

class Bomb(pygame.sprite.Sprite):
    image = load_image("new_geralt2.png")
    image_boom = load_image("new_geralt2_revers.png")
    image2 = load_image("new_geralt2.png")


    def __init__(self, group):
        # РќР•РћР‘РҐРћР”РРњРћ РІС‹Р·РІР°С‚СЊ РєРѕРЅСЃС‚СЂСѓРєС‚РѕСЂ СЂРѕРґРёС‚РµР»СЊСЃРєРѕРіРѕ РєР»Р°СЃСЃР° Sprite. Р­С‚Рѕ РѕС‡РµРЅСЊ РІР°Р¶РЅРѕ!!!
        super().__init__(group)
        self.image = Bomb.image
        self.rect = self.image.get_rect()
 
    def update(self, event):
        self.rect.x = event[0]
        self.rect.y = event[1]
        if event[2] == True:
            self.image = self.image_boom
        else:
            self.image = self.image2


all_sprites = pygame.sprite.Group()
health_sprite = pygame.sprite.Group()


Bomb(all_sprites)
for _ in range(10):
    Health_class(health_sprite)


x = 450   #coords of main character
y = 540

x_health = 940
y_health = 5

count_jump = 15   # Для уравнения прыжка

health2 = 100    # здоровье

jump_flag = False   # flag of jump process

reverse = False   # повернуть персонаж налево, или нет

running = True
while running:
    font = pygame.font.Font(None, 30)
    all_sprites.update([int(x), int(y), reverse])
    health_sprite.update([int(x_health), int(y_health)])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_d:
            x += 5
            reverse = False

    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_a:
            x -= 5
            reverse = True

    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_w:
            jump_flag = True
            count_jump = 15


    if jump_flag == True:
        if count_jump >= -15:
            y -= count_jump / 2
            count_jump -= 1
            print(count_jump)
        else:
            if y < 540:
                y = min(540, (y - count_jump / 2))
                count_jump -= 1
                print(count_jump)
                if count_jump <= -40 and count_jump >= -50:
                    health2 -= 1
                else:
                    pass
            else:
                count_jump = 15
                jump_flag = False


    screen.fill(WHITE)
    screen.blit(font.render('Health: {}%'.format(health2, 1), 1, (180, 180, 0)), (0, 0))
    all_sprites.draw(screen)
    health_sprite.draw(screen)
    pygame.display.flip()
    pygame.time.wait(8)
pygame.quit()